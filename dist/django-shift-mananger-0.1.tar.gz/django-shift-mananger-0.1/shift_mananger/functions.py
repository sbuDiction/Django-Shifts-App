
def return_json():
    workers = [{
        'week_day': "Sunday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Monday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Tuesday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Wednesday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Thursday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Friday",
        'counter': 0,
        'workers': []
    },{
        'week_day': "Saturday",
        'counter': 0,
        'workers': []
    }]

    return workers